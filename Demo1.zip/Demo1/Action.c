Action()
{
	int intResult, intSearchResult;
	int intResponseCode;

	web_add_header("Authorization", lr_eval_string("Bearer {pAccessToken}"));
    web_add_header("Content-Type", "application/json");
	    
	web_set_max_html_param_len("9999999");
	web_reg_save_param("c_fullresponse", "LB=", "RB=", LAST);
	web_reg_find("Text=11133", "SaveCount=c_searchText", LAST );

	lr_start_transaction("01");
	
	intResult = web_rest("GET: http://restapi.adequateshop.com/api/Traveler?page={pageNumber}",
		"URL=http://restapi.adequateshop.com/api/Traveler?page={pageNumber}",
		"Method=GET",
		"Snapshot=t876502.inf",
		LAST);

	lr_end_transaction("01", LR_AUTO);
	
	intResponseCode = web_get_int_property(HTTP_INFO_RETURN_CODE);
	
	lr_output_message("====================================================================================================");
	lr_output_message("Response code: %i", intResponseCode);
	
	if (intResponseCode == 200)
		lr_output_message("PASSED");
	else
		lr_output_message("FAILED");
	
	lr_output_message("====================================================================================================");
	lr_output_message("Response body:");
	lr_output_message("%s", lr_eval_string("{c_fullresponse}"));
	lr_output_message("====================================================================================================");

	if (intResult == LR_FAIL)
		lr_output_message("This is a result: FAIL");
	else if (intResult == LR_PASS)
		lr_output_message("This is a result: PASS");
	
	// check whether substring "11133" was found
	if (strcmp(lr_eval_string("{c_searchText}"), "0") > 0) {
		lr_output_message("Found text");
	} 
	else {
		lr_output_message("Not Found text");
	}
	
	return 0;
}
